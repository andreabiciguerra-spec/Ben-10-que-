package com.example.ben10.client;

import com.example.ben10.AlienForm;
import com.example.ben10.Ben10Mod;
import com.example.ben10.net.Net;
import com.example.ben10.net.SelectFormPacket;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.resources.ResourceLocation;

/**
 * Menú circular del Omnitrix. Anillo interior: 10 clásicos. Anillo exterior: 10 de Galván
 * (bloqueados hasta calibrar con Azmuth). Clic en el centro: volver a humano.
 */
public class OmnitrixScreen extends Screen {
    private static final ResourceLocation CORE =
            new ResourceLocation(Ben10Mod.MODID, "textures/item/omnitrix.png");
    private static final int HALF = 14;

    private final boolean calibrated;
    private AlienForm hovered;

    public OmnitrixScreen(boolean calibrated) {
        super(new TextComponent("Omnitrix"));
        this.calibrated = calibrated;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private int[] position(int index, int count, double radius) {
        double angle = -Math.PI / 2 + 2 * Math.PI * index / count;
        return new int[]{(int) (width / 2 + Math.cos(angle) * radius),
                (int) (height / 2 + Math.sin(angle) * radius)};
    }

    @Override
    public void render(PoseStack ps, int mouseX, int mouseY, float partialTick) {
        renderBackground(ps);
        hovered = null;

        AlienForm[] all = AlienForm.values();
        int classic = 0, ultimate = 0;
        for (AlienForm f : all) if (f.isUltimate()) ultimate++; else classic++;

        int ci = 0, ui = 0;
        for (AlienForm form : all) {
            boolean locked = form.isUltimate() && !calibrated;
            int[] p = form.isUltimate() ? position(ui++, ultimate, 112) : position(ci++, classic, 64);
            boolean over = !locked && Math.abs(mouseX - p[0]) <= HALF && Math.abs(mouseY - p[1]) <= HALF;
            if (over) hovered = form;

            int border = locked ? 0xFF2A2F36 : over ? 0xFF3CFF8C : 0xFF1E7A48;
            fill(ps, p[0] - HALF - 1, p[1] - HALF - 1, p[0] + HALF + 1, p[1] + HALF + 1, border);
            fill(ps, p[0] - HALF, p[1] - HALF, p[0] + HALF, p[1] + HALF, locked ? 0xEE0C0E12 : 0xEE10181A);

            RenderSystem.setShaderTexture(0, ClientForms.icon(form));
            RenderSystem.enableBlend();
            RenderSystem.setShaderColor(1F, 1F, 1F, locked ? 0.25F : 1F);
            blit(ps, p[0] - 12, p[1] - 12, 24, 24, 0, 0, 16, 16, 16, 16);
            RenderSystem.setShaderColor(1F, 1F, 1F, 1F);
        }

        // núcleo central
        int cx = width / 2, cy = height / 2;
        boolean overCore = Math.hypot(mouseX - cx, mouseY - cy) < 20;
        RenderSystem.setShaderTexture(0, CORE);
        RenderSystem.enableBlend();
        blit(ps, cx - 16, cy - 16, 32, 32, 0, 0, 16, 16, 16, 16);

        String label = hovered != null ? hovered.displayName()
                : overCore ? "Volver a humano"
                : calibrated ? "Omnitrix calibrado" : "Omnitrix (sin calibrar)";
        drawCenteredString(ps, font, label, cx, cy + 28, hovered != null ? 0x3CFF8C : 0xFFFFFF);

        super.render(ps, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (hovered != null) {
            Net.CHANNEL.sendToServer(new SelectFormPacket(hovered.ordinal()));
            onClose();
            return true;
        }
        if (Math.hypot(mouseX - width / 2.0, mouseY - height / 2.0) < 20) {
            Net.CHANNEL.sendToServer(new SelectFormPacket(-1));
            onClose();
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }
}
