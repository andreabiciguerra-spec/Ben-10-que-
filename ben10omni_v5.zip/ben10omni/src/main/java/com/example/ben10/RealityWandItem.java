package com.example.ben10;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Cetro de X. Shift + click derecho: cambia de modo. Click derecho: usa el modo actual.
 */
public class RealityWandItem extends Item {
    private static final String MODE_KEY = "Mode";
    private static final double RANGE = 64.0;

    public enum Mode {
        VANISH("Desaparecer (apunta a un ser)"),
        ERASE("Borrar bloques (zona 5x5x5)"),
        TIME("Cambiar entre día y noche"),
        WEATHER("Cambiar el clima"),
        NULL_VOID("Viajar al Vacío Nulo / volver");

        final String label;
        Mode(String label) { this.label = label; }
    }

    public RealityWandItem(Properties properties) {
        super(properties);
    }

    private static Mode mode(ItemStack stack) {
        int i = stack.hasTag() ? stack.getTag().getInt(MODE_KEY) : 0;
        return Mode.values()[Math.floorMod(i, Mode.values().length)];
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level.isClientSide || !(level instanceof ServerLevel server) || !(player instanceof ServerPlayer sp)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }

        if (player.isShiftKeyDown()) {
            int next = Math.floorMod(stack.getOrCreateTag().getInt(MODE_KEY) + 1, Mode.values().length);
            stack.getOrCreateTag().putInt(MODE_KEY, next);
            player.displayClientMessage(new TextComponent("Modo: " + Mode.values()[next].label), true);
            return InteractionResultHolder.success(stack);
        }

        player.getCooldowns().addCooldown(this, 10);
        switch (mode(stack)) {
            case VANISH -> vanish(server, sp);
            case ERASE -> erase(server, sp);
            case TIME -> {
                long t = server.getDayTime();
                long base = t - Math.floorMod(t, 24000L);
                boolean day = Math.floorMod(t, 24000L) < 12000L;
                server.setDayTime(day ? base + 14000L : base + 24000L + 1000L);
                player.displayClientMessage(new TextComponent(day ? "Cae la noche." : "Amanece."), true);
            }
            case WEATHER -> {
                if (server.isRaining()) {
                    server.setWeatherParameters(6000, 0, false, false);
                    player.displayClientMessage(new TextComponent("Cielo despejado."), true);
                } else {
                    server.setWeatherParameters(0, 6000, true, false);
                    player.displayClientMessage(new TextComponent("Empieza a llover."), true);
                }
            }
            case NULL_VOID -> travel(server, sp);
        }
        return InteractionResultHolder.success(stack);
    }

    private static void vanish(ServerLevel level, ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
        AABB box = player.getBoundingBox().expandTowards(player.getLookAngle().scale(RANGE)).inflate(1.0);
        EntityHitResult hit = ProjectileUtil.getEntityHitResult(player, eye, end, box,
                e -> !e.isSpectator() && e.isPickable() && !(e instanceof Player), RANGE * RANGE);
        if (hit == null) {
            player.displayClientMessage(new TextComponent("No hay nadie ahí."), true);
            return;
        }
        Entity target = hit.getEntity();
        level.sendParticles(ParticleTypes.PORTAL, target.getX(), target.getY() + target.getBbHeight() / 2,
                target.getZ(), 40, 0.4, 0.6, 0.4, 0.3);
        target.discard();
    }

    private static void erase(ServerLevel level, ServerPlayer player) {
        Vec3 eye = player.getEyePosition();
        Vec3 end = eye.add(player.getLookAngle().scale(RANGE));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.OUTLINE,
                ClipContext.Fluid.NONE, player));
        if (hit.getType() != HitResult.Type.BLOCK) {
            player.displayClientMessage(new TextComponent("Nada que borrar."), true);
            return;
        }
        BlockPos c = hit.getBlockPos();
        for (BlockPos p : BlockPos.betweenClosed(c.offset(-2, -2, -2), c.offset(2, 2, 2))) {
            BlockState state = level.getBlockState(p);
            if (!state.isAir() && state.getDestroySpeed(level, p) >= 0) { // respeta la bedrock
                level.setBlock(p, Blocks.AIR.defaultBlockState(), 3);
            }
        }
        level.sendParticles(ParticleTypes.PORTAL, c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5,
                60, 1.2, 1.2, 1.2, 0.3);
    }

    private static void travel(ServerLevel level, ServerPlayer player) {
        boolean toVoid = level.dimension() != Ben10Mod.NULL_VOID_KEY;
        ServerLevel target = level.getServer().getLevel(toVoid ? Ben10Mod.NULL_VOID_KEY : Level.OVERWORLD);
        if (target == null) {
            player.displayClientMessage(new TextComponent("Esa dimensión no está disponible."), true);
            return;
        }
        if (toVoid) {
            player.teleportTo(target, 0.5, -58, 0.5, player.getYRot(), player.getXRot());
            player.displayClientMessage(new TextComponent("Vacío Nulo."), true);
        } else {
            BlockPos spawn = target.getSharedSpawnPos();
            int y = target.getHeight(Heightmap.Types.MOTION_BLOCKING, spawn.getX(), spawn.getZ());
            player.teleportTo(target, spawn.getX() + 0.5, y, spawn.getZ() + 0.5,
                    player.getYRot(), player.getXRot());
            player.displayClientMessage(new TextComponent("De vuelta en la Tierra."), true);
        }
    }
}
