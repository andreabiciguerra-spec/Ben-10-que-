package com.example.ben10;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GreyMatterRenderer extends MobRenderer<GreyMatterEntity, GreyMatterModel> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Ben10Mod.MODID, "textures/entity/grey_matter.png");

    public GreyMatterRenderer(EntityRendererProvider.Context context) {
        super(context, new GreyMatterModel(context.bakeLayer(GreyMatterModel.LAYER)), 0.3F);
    }

    @Override
    public ResourceLocation getTextureLocation(GreyMatterEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(GreyMatterEntity entity, PoseStack poseStack, float partialTicks) {
        poseStack.scale(0.6F, 0.6F, 0.6F); // chiquitito
    }
}
