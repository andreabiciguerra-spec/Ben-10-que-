package com.example.ben10.client;

import com.example.ben10.AlienForm;
import com.example.ben10.Ben10Mod;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Dibuja el segundo par de brazos de Cuatro Brazos. */
public class FourArmsLayer extends RenderLayer<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(Ben10Mod.MODID, "extra_arms"), "main");

    private final ModelPart rightArm;
    private final ModelPart leftArm;

    public FourArmsLayer(RenderLayerParent<AbstractClientPlayer, PlayerModel<AbstractClientPlayer>> parent,
                         EntityModelSet modelSet) {
        super(parent);
        ModelPart root = modelSet.bakeLayer(LAYER);
        this.rightArm = root.getChild("right_arm");
        this.leftArm = root.getChild("left_arm");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("right_arm",
                CubeListBuilder.create().texOffs(40, 16).addBox(-3.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(-5.0F, 2.0F, 0.0F));
        root.addOrReplaceChild("left_arm",
                CubeListBuilder.create().texOffs(32, 48).addBox(-1.0F, -2.0F, -2.0F, 4.0F, 12.0F, 4.0F),
                PartPose.offset(5.0F, 2.0F, 0.0F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight,
                       AbstractClientPlayer player, float limbSwing, float limbSwingAmount,
                       float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (ClientForms.get(player.getId()) != AlienForm.FOUR_ARMS) return;

        PlayerModel<AbstractClientPlayer> model = getParentModel();
        rightArm.copyFrom(model.rightArm);
        leftArm.copyFrom(model.leftArm);
        // segundo par: más abajo y un poco hacia afuera, balanceándose al revés
        rightArm.y += 5.0F;
        leftArm.y += 5.0F;
        rightArm.x -= 1.0F;
        leftArm.x += 1.0F;
        rightArm.xRot = -model.rightArm.xRot * 0.8F;
        leftArm.xRot = -model.leftArm.xRot * 0.8F;

        VertexConsumer consumer = buffer.getBuffer(
                RenderType.entityCutoutNoCull(ClientForms.skin(AlienForm.FOUR_ARMS)));
        rightArm.render(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY);
        leftArm.render(poseStack, consumer, packedLight, OverlayTexture.NO_OVERLAY);
    }
}
