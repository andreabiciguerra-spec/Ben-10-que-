package com.example.ben10;

import com.example.ben10.net.Net;
import com.mojang.math.Vector3f;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.Registry;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.Material;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(Ben10Mod.MODID)
public class Ben10Mod {
    public static final String MODID = "ben10omni";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITIES, MODID);

    public static final RegistryObject<Item> OMNITRIX = ITEMS.register("omnitrix",
            () -> new OmnitrixItem(new Item.Properties().tab(CreativeModeTab.TAB_TOOLS).stacksTo(1)));

    public static final RegistryObject<Item> AZMUTH_CALIBRATOR = ITEMS.register("azmuth_calibrator",
            () -> new CalibrationItem(new Item.Properties().tab(CreativeModeTab.TAB_MISC).stacksTo(1)));

    public static final RegistryObject<Item> REALITY_WAND = ITEMS.register("reality_wand",
            () -> new RealityWandItem(new Item.Properties().tab(CreativeModeTab.TAB_TOOLS).stacksTo(1)));

    public static final RegistryObject<Block> ROCKET_BLOCK = BLOCKS.register("rocket",
            () -> new RocketBlock(BlockBehaviour.Properties.of(Material.METAL).strength(3.0F).noOcclusion()));
    public static final RegistryObject<Item> ROCKET_ITEM = ITEMS.register("rocket",
            () -> new BlockItem(ROCKET_BLOCK.get(), new Item.Properties().tab(CreativeModeTab.TAB_TRANSPORTATION)));

    public static final RegistryObject<Block> GALVAN_GROUND = BLOCKS.register("galvan_ground",
            () -> new Block(BlockBehaviour.Properties.of(Material.GRASS).strength(0.6F).sound(SoundType.GRASS)));
    public static final RegistryObject<Item> GALVAN_GROUND_ITEM = ITEMS.register("galvan_ground",
            () -> new BlockItem(GALVAN_GROUND.get(), new Item.Properties().tab(CreativeModeTab.TAB_BUILDING_BLOCKS)));

    public static final RegistryObject<EntityType<GreyMatterEntity>> GREY_MATTER = ENTITIES.register("grey_matter",
            () -> EntityType.Builder.of(GreyMatterEntity::new, MobCategory.CREATURE)
                    .sized(0.4F, 0.9F)
                    .build("grey_matter"));

    /** Dimensión Galván (definida en data/ben10omni/dimension/galvan.json). */
    public static final ResourceKey<Level> GALVAN_KEY =
            ResourceKey.create(Registry.DIMENSION_REGISTRY, new ResourceLocation(MODID, "galvan"));

    /** Dimensión Vacío Nulo (data/ben10omni/dimension/null_void.json). */
    public static final ResourceKey<Level> NULL_VOID_KEY =
            ResourceKey.create(Registry.DIMENSION_REGISTRY, new ResourceLocation(MODID, "null_void"));

    private static final String METEOR_KEY = "ben10_meteor";

    public Ben10Mod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(modBus);
        BLOCKS.register(modBus);
        ENTITIES.register(modBus);
        modBus.addListener(this::onEntityAttributes);
        modBus.addListener((FMLCommonSetupEvent e) -> e.enqueueWork(Net::register));
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void onEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(GREY_MATTER.get(), GreyMatterEntity.createAttributes().build());
    }

    @SubscribeEvent
    public void onStartTracking(PlayerEvent.StartTracking event) {
        if (event.getTarget() instanceof Player target && event.getPlayer() instanceof ServerPlayer receiver) {
            Net.syncTo(receiver, target);
        }
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        Net.sync(event.getPlayer()); // al morir se pierde la transformación
    }

    @SubscribeEvent
    public void onDimensionChange(PlayerEvent.PlayerChangedDimensionEvent event) {
        Net.sync(event.getPlayer());
    }

    /** Al entrar por primera vez, cae un meteorito con el Omnitrix y el núcleo de Azmuth. */
    @SubscribeEvent
    public void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        Player player = event.getPlayer();
        Level level = player.level;
        if (level.isClientSide) return;

        Net.sync(player);
        CompoundTag data = player.getPersistentData();
        if (data.getBoolean(METEOR_KEY)) return;
        data.putBoolean(METEOR_KEY, true);

        double x = player.getX() + (level.random.nextDouble() * 30 - 15);
        double z = player.getZ() + (level.random.nextDouble() * 30 - 15);
        double y = Math.min(player.getY() + 80, 250);

        level.addFreshEntity(new ItemEntity(level, x, y, z, new ItemStack(OMNITRIX.get())));
        level.addFreshEntity(new ItemEntity(level, x + 1, y, z, new ItemStack(AZMUTH_CALIBRATOR.get())));
        player.sendMessage(new TextComponent("¡Un meteorito cae del cielo cerca de ti!"),
                net.minecraft.Util.NIL_UUID);
    }

    /** Tick del jugador: calibración y refresco de los efectos del alienígena activo. */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Player player = event.player;
        Level level = player.level;
        if (level.isClientSide) return;

        CompoundTag data = player.getPersistentData();

        int calib = data.getInt(CalibrationItem.CALIBRATING_KEY);
        if (calib > 0) {
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(
                        new DustParticleOptions(new Vector3f(0.2F, 0.6F, 1.0F), 1.5F),
                        player.getX(), player.getY() + 1.0, player.getZ(),
                        12, 0.4, 0.7, 0.4, 0.02);
            }
            data.putInt(CalibrationItem.CALIBRATING_KEY, calib - 1);

            if (calib - 1 == 0) {
                ItemStack omnitrix = CalibrationItem.findOmnitrix(player);
                if (!omnitrix.isEmpty()) {
                    omnitrix.getOrCreateTag().putBoolean("Calibrated", true);
                    player.displayClientMessage(
                            new TextComponent("¡Calibración completa! 10 alienígenas nuevos desbloqueados."), true);
                }
            }
        }

        int form = data.getInt(OmnitrixItem.ALIEN_KEY);
        if (form != 0 && player.tickCount % 100 == 0) {
            OmnitrixItem.applyEffects(player, AlienForm.fromId(form - 1));
        }
    }
}
