package com.example.ben10.net;

import com.example.ben10.AlienForm;
import com.example.ben10.CalibrationItem;
import com.example.ben10.OmnitrixItem;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Cliente -> servidor: elegir alienígena en el menú circular (-1 = volver a humano). */
public class SelectFormPacket {
    private final int index;

    public SelectFormPacket(int index) {
        this.index = index;
    }

    public static void encode(SelectFormPacket p, FriendlyByteBuf buf) {
        buf.writeInt(p.index);
    }

    public static SelectFormPacket decode(FriendlyByteBuf buf) {
        return new SelectFormPacket(buf.readInt());
    }

    public static void handle(SelectFormPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;

            ItemStack omnitrix = CalibrationItem.findOmnitrix(player);
            if (omnitrix.isEmpty()) return;

            boolean transformed = player.getPersistentData().getInt(OmnitrixItem.ALIEN_KEY) != 0;
            if (p.index < 0) {
                if (transformed) OmnitrixItem.revert(player);
                return;
            }
            if (p.index >= AlienForm.values().length) return;

            AlienForm form = AlienForm.fromId(p.index);
            if (form.isUltimate() && !OmnitrixItem.isCalibrated(omnitrix)) return; // validación servidor
            if (transformed) OmnitrixItem.revert(player);
            OmnitrixItem.transform(player, form);
        });
        ctx.get().setPacketHandled(true);
    }
}
