package com.example.ben10.client;

import com.example.ben10.AlienForm;
import com.example.ben10.Ben10Mod;
import net.minecraft.resources.ResourceLocation;

import java.util.HashMap;
import java.util.Map;

/** Estado del lado cliente: qué alienígena es cada jugador (por id de entidad). */
public class ClientForms {
    public static final ResourceLocation BEN =
            new ResourceLocation(Ben10Mod.MODID, "textures/entity/ben10.png");

    private static final Map<Integer, Integer> FORMS = new HashMap<>();

    public static void set(int entityId, int form) {
        if (form == 0) FORMS.remove(entityId);
        else FORMS.put(entityId, form);
    }

    /** null = forma humana (Ben). */
    public static AlienForm get(int entityId) {
        Integer v = FORMS.get(entityId);
        return v == null ? null : AlienForm.fromId(v - 1);
    }

    public static ResourceLocation skin(AlienForm form) {
        return new ResourceLocation(Ben10Mod.MODID, "textures/entity/alien/" + form.key() + ".png");
    }

    public static ResourceLocation icon(AlienForm form) {
        return new ResourceLocation(Ben10Mod.MODID, "textures/item/alien/" + form.key() + ".png");
    }
}
