package com.example.ben10;

import net.minecraft.network.chat.TextComponent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * "Núcleo de calibración de Azmuth". Al usarlo con un Omnitrix en el inventario,
 * el Omnitrix se pone azul unos segundos y queda calibrado (desbloquea 10 formas nuevas).
 */
public class CalibrationItem extends Item {
    public static final String CALIBRATING_KEY = "ben10_calib"; // ticks restantes en el jugador

    public CalibrationItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide) {
            ItemStack omnitrix = findOmnitrix(player);
            if (omnitrix.isEmpty()) {
                player.displayClientMessage(new TextComponent("Necesitas un Omnitrix en el inventario."), true);
            } else if (OmnitrixItem.isCalibrated(omnitrix)) {
                player.displayClientMessage(new TextComponent("Tu Omnitrix ya está calibrado."), true);
            } else if (player.getPersistentData().getInt(CALIBRATING_KEY) > 0) {
                player.displayClientMessage(new TextComponent("Ya se está calibrando..."), true);
            } else {
                player.getPersistentData().putInt(CALIBRATING_KEY, 100); // 5 segundos
                if (!player.isCreative()) stack.shrink(1);
                player.displayClientMessage(new TextComponent("Calibrando con Azmuth..."), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    public static ItemStack findOmnitrix(Player player) {
        for (ItemStack s : player.getInventory().items) {
            if (s.getItem() instanceof OmnitrixItem) return s;
        }
        return ItemStack.EMPTY;
    }
}
