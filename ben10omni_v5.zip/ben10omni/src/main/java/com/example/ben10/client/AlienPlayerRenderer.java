package com.example.ben10.client;

import com.example.ben10.AlienForm;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraft.resources.ResourceLocation;

/**
 * Renderer del jugador: usa la skin de Ben 10 en forma humana, la skin del alienígena
 * al transformarse y escala el modelo según el alienígena.
 */
public class AlienPlayerRenderer extends PlayerRenderer {

    public AlienPlayerRenderer(EntityRendererProvider.Context context) {
        super(context, false);
        this.addLayer(new FourArmsLayer(this, context.getModelSet()));
    }

    @Override
    public ResourceLocation getTextureLocation(AbstractClientPlayer player) {
        AlienForm form = ClientForms.get(player.getId());
        return form == null ? ClientForms.BEN : ClientForms.skin(form);
    }

    @Override
    protected void scale(AbstractClientPlayer player, PoseStack poseStack, float partialTick) {
        super.scale(player, poseStack, partialTick);
        AlienForm form = ClientForms.get(player.getId());
        if (form != null) {
            float s = form.scale();
            poseStack.scale(s, s, s);
        }
    }
}
