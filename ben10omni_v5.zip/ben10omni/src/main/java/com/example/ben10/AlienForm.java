package com.example.ben10;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffects;

/**
 * Los alienígenas del Omnitrix. Cada forma da efectos de poción como
 * "poderes". Las formas ULTIMATE solo se desbloquean tras la calibración.
 */
public enum AlienForm {
    // ---- Los 10 clásicos ----
    FOUR_ARMS("Cuatro Brazos", 0xB3261E, false,
            new EffectSpec(MobEffects.DAMAGE_BOOST, 1),
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 0)),
    HEATBLAST("Heatblast", 0xFF6A00, false,
            new EffectSpec(MobEffects.FIRE_RESISTANCE, 0),
            new EffectSpec(MobEffects.DAMAGE_BOOST, 0)),
    WILDMUTT("Wildmutt", 0xE8B923, false,
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 1),
            new EffectSpec(MobEffects.JUMP, 1)),
    DIAMONDHEAD("Diamante", 0x7FE6FF, false,
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 2)),
    XLR8("XLR8", 0x2E7D32, false,
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 3)),
    GREY_MATTER("Materia Gris", 0x9E9E9E, false,
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 2),
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 0)),
    UPGRADE("Mejora", 0x8E9AAF, false,
            new EffectSpec(MobEffects.DIG_SPEED, 1),
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 1)),
    RIPJAWS("Mandíbulas", 0x1E88E5, false,
            new EffectSpec(MobEffects.WATER_BREATHING, 0),
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 1)),
    STINKFLY("Mosca Apestosa", 0x7CB342, false,
            new EffectSpec(MobEffects.JUMP, 2),
            new EffectSpec(MobEffects.SLOW_FALLING, 0)),
    CANNONBOLT("Cañón Bola", 0x6D4C41, false,
            new EffectSpec(MobEffects.JUMP, 2),
            new EffectSpec(MobEffects.DAMAGE_BOOST, 0)),

    // ---- Las 10 nuevas de Galván (tras calibrar con Azmuth) ----
    NOVA_RAYO("Nova Rayo", 0xFFEB3B, true,
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 3),
            new EffectSpec(MobEffects.DAMAGE_BOOST, 1)),
    ZETA_TITAN("Zeta Titán", 0x5E35B1, true,
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 3),
            new EffectSpec(MobEffects.REGENERATION, 0)),
    ECLIPSE_SOMBRA("Eclipse Sombra", 0x212121, true,
            new EffectSpec(MobEffects.INVISIBILITY, 0),
            new EffectSpec(MobEffects.NIGHT_VISION, 0)),
    AZUL_HIDRO("Azul Hidro", 0x00ACC1, true,
            new EffectSpec(MobEffects.WATER_BREATHING, 0),
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 1)),
    GALVAN_CRISTAL("Galván Cristal", 0xCE93D8, true,
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 2),
            new EffectSpec(MobEffects.DIG_SPEED, 2)),
    MAGMA_ORION("Magma Orión", 0xBF360C, true,
            new EffectSpec(MobEffects.FIRE_RESISTANCE, 0),
            new EffectSpec(MobEffects.DAMAGE_BOOST, 2)),
    VORTEX_ALADA("Vórtex Alada", 0xB0BEC5, true,
            new EffectSpec(MobEffects.SLOW_FALLING, 0),
            new EffectSpec(MobEffects.JUMP, 3)),
    ECO_VERDE("Eco Verde", 0x43A047, true,
            new EffectSpec(MobEffects.REGENERATION, 1)),
    PULSAR_ASTRAL("Pulsar Astral", 0x3949AB, true,
            new EffectSpec(MobEffects.JUMP, 2),
            new EffectSpec(MobEffects.MOVEMENT_SPEED, 2)),
    TITAN_GALVAN("Titán Galván", 0xFF7043, true,
            new EffectSpec(MobEffects.DAMAGE_BOOST, 3),
            new EffectSpec(MobEffects.DAMAGE_RESISTANCE, 3));

    /** Un efecto de poción con su nivel (amplifier 0 = nivel I). */
    public record EffectSpec(MobEffect effect, int amplifier) {}

    private final String displayName;
    private final int color;
    private final boolean ultimate;
    private final EffectSpec[] effects;

    AlienForm(String displayName, int color, boolean ultimate, EffectSpec... effects) {
        this.displayName = displayName;
        this.color = color;
        this.ultimate = ultimate;
        this.effects = effects;
    }

    public String displayName() { return displayName; }
    public int color() { return color; }
    public boolean isUltimate() { return ultimate; }
    public EffectSpec[] effects() { return effects; }

    /** Escala del modelo del jugador al transformarse (Materia Gris pequeño, Titanes enormes). */
    public float scale() {
        switch (this) {
            case GREY_MATTER: return 0.5F;
            case WILDMUTT: return 0.9F;
            case UPGRADE: return 1.05F;
            case DIAMONDHEAD: return 1.15F;
            case CANNONBOLT: return 1.15F;
            case RIPJAWS: return 1.1F;
            case FOUR_ARMS: return 1.25F;
            case ZETA_TITAN: return 1.3F;
            case MAGMA_ORION: return 1.3F;
            case TITAN_GALVAN: return 1.4F;
            default: return 1.0F;
        }
    }

    /** Nombre de archivo de skin / ícono (ej. "four_arms"). */
    public String key() {
        return name().toLowerCase();
    }

    public static AlienForm fromId(int id) {
        return values()[Math.floorMod(id, values().length)];
    }
}
