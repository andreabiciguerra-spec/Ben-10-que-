package com.example.ben10.net;

import com.example.ben10.Ben10Mod;
import com.example.ben10.OmnitrixItem;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Ben10Mod.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, SelectFormPacket.class,
                SelectFormPacket::encode, SelectFormPacket::decode, SelectFormPacket::handle);
        CHANNEL.registerMessage(id++, SyncFormPacket.class,
                SyncFormPacket::encode, SyncFormPacket::decode, SyncFormPacket::handle);
    }

    /** Envía la forma actual del jugador a él mismo y a quienes lo ven. */
    public static void sync(Player player) {
        if (!(player instanceof ServerPlayer sp)) return;
        int form = sp.getPersistentData().getInt(OmnitrixItem.ALIEN_KEY);
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY_AND_SELF.with(() -> sp),
                new SyncFormPacket(sp.getId(), form));
    }

    /** Envía la forma de `target` a un único jugador (cuando empieza a verlo). */
    public static void syncTo(ServerPlayer receiver, Player target) {
        int form = target.getPersistentData().getInt(OmnitrixItem.ALIEN_KEY);
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> receiver),
                new SyncFormPacket(target.getId(), form));
    }
}
