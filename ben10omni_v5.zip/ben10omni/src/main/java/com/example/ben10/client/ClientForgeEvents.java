package com.example.ben10.client;

import com.example.ben10.Ben10Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Ben10Mod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientForgeEvents {
    private static AlienPlayerRenderer renderer;

    /** Reemplaza el render del jugador por el de Ben 10 / alienígena. */
    @SubscribeEvent
    public static void onRenderPlayer(RenderPlayerEvent.Pre event) {
        if (event.getRenderer() instanceof AlienPlayerRenderer) return; // evita recursión
        if (!(event.getPlayer() instanceof AbstractClientPlayer player)) return;

        if (renderer == null) {
            Minecraft mc = Minecraft.getInstance();
            renderer = new AlienPlayerRenderer(new EntityRendererProvider.Context(
                    mc.getEntityRenderDispatcher(), mc.getItemRenderer(), mc.getResourceManager(),
                    mc.getEntityModels(), mc.font));
        }
        event.setCanceled(true);
        renderer.render(player, player.getYRot(), event.getPartialTick(),
                event.getPoseStack(), event.getMultiBufferSource(), event.getPackedLight());
    }

    /** Tecla del Omnitrix: abre el menú circular. */
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        while (ClientEvents.OPEN_DIAL.consumeClick()) {
            if (mc.player == null || mc.screen != null) continue;
            var omnitrix = com.example.ben10.CalibrationItem.findOmnitrix(mc.player);
            if (omnitrix.isEmpty()) {
                mc.player.displayClientMessage(
                        new net.minecraft.network.chat.TextComponent("No tienes un Omnitrix."), true);
            } else {
                mc.setScreen(new OmnitrixScreen(com.example.ben10.OmnitrixItem.isCalibrated(omnitrix)));
            }
        }
    }
}
