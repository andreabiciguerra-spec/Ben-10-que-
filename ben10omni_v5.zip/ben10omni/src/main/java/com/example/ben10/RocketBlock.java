package com.example.ben10;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.resources.ResourceKey;

import java.util.List;

/**
 * Cohete: al usarlo viajas a Galván o vuelves a la Tierra.
 * Al llegar a Galván aparece Azmuth (aldeano) con sus trueques y algunos Materia Gris.
 */
public class RocketBlock extends Block {
    private static final String AZMUTH_TAG = "ben10_azmuth";

    public RocketBlock(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
            MinecraftServer server = serverLevel.getServer();
            boolean toGalvan = player.level.dimension() != Ben10Mod.GALVAN_KEY;
            ResourceKey<Level> target = toGalvan ? Ben10Mod.GALVAN_KEY : Level.OVERWORLD;
            ServerLevel targetLevel = server.getLevel(target);

            if (targetLevel != null) {
                Entity moved = serverPlayer.changeDimension(targetLevel);
                if (moved != null) {
                    if (toGalvan) {
                        moved.teleportTo(0.5, -58, 0.5);
                        spawnAzmuthIfMissing(targetLevel);
                        moved.sendMessage(new TextComponent("Bienvenido a Galván."), net.minecraft.Util.NIL_UUID);
                    } else {
                        moved.teleportTo(serverPlayer.getX(), 64, serverPlayer.getZ());
                    }
                }
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private static void spawnAzmuthIfMissing(ServerLevel galvan) {
        AABB area = new AABB(-48, -70, -48, 48, -40, 48);
        List<Villager> existing = galvan.getEntitiesOfClass(Villager.class, area,
                v -> v.getTags().contains(AZMUTH_TAG));
        if (!existing.isEmpty()) return;

        Villager azmuth = EntityType.VILLAGER.create(galvan);
        if (azmuth == null) return;
        azmuth.moveTo(3.5, -58, 3.5, 0, 0);
        azmuth.setCustomName(new TextComponent("Azmuth"));
        azmuth.setCustomNameVisible(true);
        azmuth.addTag(AZMUTH_TAG);
        azmuth.setPersistenceRequired();

        // Trueque: el Omnitrix normal -> Omnitrix calibrado
        ItemStack calibrated = new ItemStack(Ben10Mod.OMNITRIX.get());
        calibrated.getOrCreateTag().putBoolean("Calibrated", true);
        azmuth.getOffers().add(new MerchantOffer(
                new ItemStack(Ben10Mod.OMNITRIX.get()), ItemStack.EMPTY, calibrated, 1, 0, 0.0f));
        galvan.addFreshEntity(azmuth);

        for (int i = 0; i < 3; i++) {
            GreyMatterEntity gm = Ben10Mod.GREY_MATTER.get().create(galvan);
            if (gm != null) {
                gm.moveTo(-4 + i * 3.0, -58, 6, 0, 0);
                gm.finalizeSpawn(galvan, galvan.getCurrentDifficultyAt(gm.blockPosition()),
                        MobSpawnType.EVENT, null, null);
                galvan.addFreshEntity(gm);
            }
        }
    }
}
