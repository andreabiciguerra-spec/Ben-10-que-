package com.example.ben10;

import com.example.ben10.net.Net;
import net.minecraft.network.chat.TextComponent;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

/**
 * Click derecho: transforma / revierte.
 * Shift + click derecho: cambia el alienígena seleccionado (el "dial").
 */
public class OmnitrixItem extends Item {
    public static final String ALIEN_KEY = "ben10_form";     // en el jugador: 0 = humano, n = AlienForm[n-1]
    private static final String SELECTED = "Selected";       // en el Omnitrix: índice del dial
    private static final String CALIBRATED = "Calibrated";   // en el Omnitrix: ¿calibrado?
    private static final int EFFECT_TICKS = 220;             // se refresca cada 100 ticks

    public OmnitrixItem(Properties properties) {
        super(properties);
    }

    /** Formas disponibles según si el Omnitrix está calibrado. */
    public static List<AlienForm> available(ItemStack stack) {
        boolean calibrated = isCalibrated(stack);
        List<AlienForm> list = new ArrayList<>();
        for (AlienForm form : AlienForm.values()) {
            if (!form.isUltimate() || calibrated) list.add(form);
        }
        return list;
    }

    public static boolean isCalibrated(ItemStack stack) {
        return stack.hasTag() && stack.getTag().getBoolean(CALIBRATED);
    }

    public static AlienForm selected(ItemStack stack) {
        List<AlienForm> list = available(stack);
        int index = stack.hasTag() ? stack.getTag().getInt(SELECTED) : 0;
        return list.get(Math.floorMod(index, list.size()));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (!level.isClientSide) {
            CompoundTag data = player.getPersistentData();

            if (player.isShiftKeyDown()) {
                // Cambiar alienígena en el dial
                List<AlienForm> list = available(stack);
                int next = Math.floorMod(stack.getOrCreateTag().getInt(SELECTED) + 1, list.size());
                stack.getOrCreateTag().putInt(SELECTED, next);
                player.displayClientMessage(
                        new TextComponent("Alienígena: " + list.get(next).displayName()), true);
            } else if (data.getInt(ALIEN_KEY) != 0) {
                revert(player);
            } else {
                transform(player, selected(stack));
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    public static void transform(Player player, AlienForm form) {
        player.getPersistentData().putInt(ALIEN_KEY, form.ordinal() + 1);
        applyEffects(player, form);
        Net.sync(player);
        player.displayClientMessage(new TextComponent("¡" + form.displayName() + "!"), true);
    }

    public static void revert(Player player) {
        player.getPersistentData().putInt(ALIEN_KEY, 0);
        for (AlienForm form : AlienForm.values()) {
            for (AlienForm.EffectSpec spec : form.effects()) {
                player.removeEffect(spec.effect());
            }
        }
        Net.sync(player);
        player.displayClientMessage(new TextComponent("Volviste a tu forma humana"), true);
    }

    /** Aplica los efectos de la forma. Se llama al transformar y se refresca en el tick del jugador. */
    public static void applyEffects(Player player, AlienForm form) {
        for (AlienForm.EffectSpec spec : form.effects()) {
            player.addEffect(new MobEffectInstance(spec.effect(), EFFECT_TICKS, spec.amplifier(), false, true));
        }
    }
}
