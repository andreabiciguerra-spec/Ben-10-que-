package com.example.ben10.net;

import com.example.ben10.client.ClientForms;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Servidor -> clientes: qué forma (0 = humano) tiene la entidad con ese id. */
public class SyncFormPacket {
    private final int entityId;
    private final int form;

    public SyncFormPacket(int entityId, int form) {
        this.entityId = entityId;
        this.form = form;
    }

    public static void encode(SyncFormPacket p, FriendlyByteBuf buf) {
        buf.writeInt(p.entityId);
        buf.writeInt(p.form);
    }

    public static SyncFormPacket decode(FriendlyByteBuf buf) {
        return new SyncFormPacket(buf.readInt(), buf.readInt());
    }

    public static void handle(SyncFormPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientForms.set(p.entityId, p.form)));
        ctx.get().setPacketHandled(true);
    }
}
